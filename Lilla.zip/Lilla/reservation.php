<?php
// (A) PROCESS RESERVATION
if (isset($_POST["date"])) {
  require "reserve.php";
  if ($_RSV->save(
    $_POST["date"], $_POST["slot"], $_POST["name"],
    $_POST["email"], $_POST["tel"], $_POST["notes"])) {
     echo "<div class='note'>Reservation saved.</div>";
  } else { echo "<div class='note'>".$_RSV->error."</div>"; }
}
?>

<!-- (B) RESERVATION FORM -->
<form id="resForm" method="post" target="_self">
  <label>Name</label>
  <input type="text" required name="name"><br>

  <label>Email</label>
  <input type="email" required name="email"><br>

  <label>Telephone Number</label>
  <input type="text" required name="tel"><br>

  <label>Notes (if any)</label>
  <input type="text" name="notes"><br>

  <?php
  // @TODO - MINIMUM DATE (TODAY)
  // $mindate = date("Y-m-d", strtotime("+2 days"));
  $mindate = date("Y-m-d");
  ?>
  <label>Reservation Date</label>
  <input type="date" required name="date" value="<?=date("Y-m-d")?>">

  <label>Reservation Slot</label>
  <select name="slot">
    <option value="AM">AM</option>
    <option value="PM">PM</option>
  </select>
  <br>
  <input type="submit" value="Submit">
</form>
